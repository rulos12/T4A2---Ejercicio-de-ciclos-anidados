package t4a2;

import java.util.Scanner;

/**
 *
 * @author Raul
 */
public class T4A2 {

    public static void main(String[] args) {
        //ejercicio1();
        //ejercicio2();
        //ejercicio3();
        ejercicio4();
    }

    public static void ejercicio1() {

        for (int j = 1; j <= 10; j++) {
            for (int i = 1; i <= 10; i++) {

                System.out.println(i + " x " + j + " = " + (i * j));
            }
            System.out.println("\n");
        }
    }

    /*realizar un programa en java que pida un numero x, y nos diga cuantos hay entre 1 y n que son primos */
    public static void ejercicio2() {
        Scanner obj = new Scanner(System.in);

        int x, a = 0, b = 0;
        System.out.println("Digite un numero");
        x = obj.nextInt();
        if (x < 1) {
            System.out.println("El numero no es valido");
        } else {

            for (int i = 1; i <= x; i++) {
                int c = 0;
                for (int j = 1; j <= i; j++) {
                    if (i % j == 0) {
                        c++;
                    }
                }
                if (c == 2) {
                    System.out.println(i);
                    a++;
                } else {
                    b++;
                }

            }
            System.out.println("Numeros primos " + a
                    + "\nNumero no primos " + b);
        }
    }

    public static void ejercicio3() {
        //Realizar un programa en Java que pida un número x, y nos diga cuántos números hay entre 1 y x, cuántos pares y cuántos impares.
        Scanner obj = new Scanner(System.in);
        int x, a = 0, b = 0, c = 0;;
        System.out.println("Digite un numero");
        x = obj.nextInt();
        if (x < 1) {
            System.out.println("El numero no es valido");
        } else {

            for (int i = 1; i <= x; i++) {

                if (i % 2 == 0) {
                    c++;
                    System.out.println(i);
                } else {
                    b++;
                }

            }
        }
        System.out.println("Numeros pares " + c
                + "\nNumero no pares " + b);
    }

    public static void ejercicio4() {
        //Un programa en Java que te permita ingresar una palabra y la imprima al revés.
        Scanner obj = new Scanner(System.in);
        String palabra, invertida="";
        System.out.println("Ingrese la palabra a invertir");
         palabra=obj.next();
        
        for (int i = palabra.length() -1; i >= 0; i--) {
            invertida+=palabra.charAt(i);
            
        }
        System.out.println("Palabra original: "+palabra);
        System.out.println("Palabra invertida: "+invertida);
    }
}
